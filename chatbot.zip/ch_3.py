import openai
import sys
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QPushButton, QLabel
)

# تنظیم API Key
api_key = "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"  # کلید API خودت رو اینجا قرار بده

# تابع تولید پاسخ با GPT
def generate_response(prompt):
    client = openai.OpenAI(api_key=api_key)  # ایجاد کلاینت جدید با کلید API
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",  # مدل GPT-3.5
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt}
        ]
    )
    return response.choices[0].message.content.strip()

# ایجاد کلاس اصلی برنامه
class CreativeChatApp(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        # تنظیمات پنجره
        self.setWindowTitle("چت‌بات خلاقانه با GPT")
        self.setGeometry(100, 100, 500, 600)

        # ایجاد لایه‌بندی عمودی
        layout = QVBoxLayout()

        # ایجاد ویجت‌ها
        self.chat_area = QTextEdit()
        self.chat_area.setReadOnly(True)
        self.input_box = QLineEdit()
        self.send_button = QPushButton("ارسال")

        # اضافه کردن ویجت‌ها به لایه‌بندی
        layout.addWidget(QLabel("چت‌بات خلاقانه:"))
        layout.addWidget(self.chat_area)
        layout.addWidget(self.input_box)
        layout.addWidget(self.send_button)

        # تنظیم لایه‌بندی
        self.setLayout(layout)

        # اتصال دکمه ارسال به تابع ارسال پیام
        self.send_button.clicked.connect(self.send_message)

    def send_message(self):
        user_input = self.input_box.text()
        self.chat_area.append(f"شما: {user_input}")

        # تولید پاسخ با GPT
        response = generate_response(user_input)
        self.chat_area.append(f"چت‌بات: {response}")

        # پاک کردن فیلد ورودی
        self.input_box.clear()

# اجرای برنامه
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = CreativeChatApp()
    window.show()
    sys.exit(app.exec())