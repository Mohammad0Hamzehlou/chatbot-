import sys
import os
import subprocess
import requests
from bs4 import BeautifulSoup
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QPushButton, QMessageBox
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QTextCursor, QColor
from textblob import TextBlob
import ollama
from datetime import datetime

# Reminder class to store reminders
class Reminder:
    def __init__(self, time, message):
        self.time = time
        self.message = message

# Function to analyze sentiment
def analyze_sentiment(text):
    """
    Analyzes the sentiment of the given text.
    Returns the sentiment ("happy", "sad", or "neutral") and a corresponding color.
    """
    analysis = TextBlob(text)
    if analysis.sentiment.polarity > 0.2:  # Positive sentiment
        return "happy", QColor(0, 128, 0)  # Green for happy
    elif analysis.sentiment.polarity < -0.2:  # Negative sentiment
        return "sad", QColor(255, 0, 0)  # Red for sad
    else:  # Neutral sentiment
        return "neutral", QColor(0, 0, 255)  # Blue for neutral

# Function to generate response using Mistral
def generate_response(user_input, sentiment):
    """
    Generates a response using the Mistral model based on the user's input and sentiment.
    """
    prompt = f"""
    You are Zero, a wise and obedient young boy who is always ready to help.
    The user is feeling {sentiment} and said: {user_input}
    Respond to them in a calm, knowledgeable, and friendly manner:
    """
    response = ollama.generate(model="mistral", prompt=prompt)
    return response['response']

# Function to save conversation to a file
def save_conversation(conversation):
    """
    Saves the conversation to a file named 'chat_history.txt'.
    """
    with open("chat_history.txt", "a", encoding="utf-8") as file:
        file.write(f"Conversation on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        file.write(conversation + "\n\n")

# Function to check if the user wants to set a reminder
def is_reminder_request(message):
    """
    Checks if the user's message is a request to set a reminder.
    """
    reminder_keywords = ["remember", "remind me", "set a reminder"]
    return any(keyword in message.lower() for keyword in reminder_keywords)

# Function to check if the user wants to access system features
def is_system_request(message):
    """
    Checks if the user's message is a request to access system features.
    """
    system_keywords = ["open", "delete", "create", "run", "change", "settings"]
    return any(keyword in message.lower() for keyword in system_keywords)

# Function to check if the user wants to search the web
def is_search_request(message):
    """
    Checks if the user's message is a request to search the web.
    """
    search_keywords = ["search", "find", "look up"]
    return any(keyword in message.lower() for keyword in search_keywords)

# Function to perform a web search using DuckDuckGo
def search_web(query):
    """
    Performs a web search using DuckDuckGo.
    Returns the top 5 search results.
    """
    url = f"https://html.duckduckgo.com/html/?q={query}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, "html.parser")
        results = []
        for result in soup.find_all("div", class_="result"):
            title = result.find("a", class_="result__a").text
            link = result.find("a", class_="result__a")["href"]
            results.append({"title": title, "link": link})
            if len(results) == 5:  # Limit to top 5 results
                break
        return results
    else:
        return None

# Main GUI class
class ChatbotGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.reminders = []  # List to store reminders
        self.initUI()
        self.timer = QTimer()
        self.timer.timeout.connect(self.check_reminders)
        self.timer.start(60000)  # Check reminders every minute

    def initUI(self):
        """
        Initializes the user interface.
        """
        self.setWindowTitle("Zero -(0)")
        self.setGeometry(100, 100, 600, 400)

        layout = QVBoxLayout()

        # Text box to display the conversation
        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        layout.addWidget(self.chat_display)

        # Input field for the user
        self.user_input = QLineEdit()
        self.user_input.setPlaceholderText("Type your message here...")
        self.user_input.returnPressed.connect(self.send_message)
        layout.addWidget(self.user_input)

        # Send button
        send_button = QPushButton("Send")
        send_button.clicked.connect(self.send_message)
        layout.addWidget(send_button)

        self.setLayout(layout)

    def send_message(self):
        """
        Handles sending a message and generating a response.
        """
        user_message = self.user_input.text()
        if user_message.strip() == "":
            return  # Do nothing if the message is empty

        # Check if the user wants to set a reminder
        if is_reminder_request(user_message):
            self.set_reminder_interactive()
            return

        # Check if the user wants to access system features
        if is_system_request(user_message):
            self.handle_system_request(user_message)
            return

        # Check if the user wants to search the web
        if is_search_request(user_message):
            self.handle_search_request(user_message)
            return

        # Display the user's message
        self.chat_display.append(f"You: {user_message}")
        self.user_input.clear()

        # Analyze sentiment and generate a response
        sentiment, color = analyze_sentiment(user_message)
        response = generate_response(user_message, sentiment)

        # Display the chatbot's response
        self.chat_display.setTextColor(color)
        self.chat_display.append(f"Zero: {response}\n")

        # Auto-scroll to the bottom
        self.chat_display.moveCursor(QTextCursor.MoveOperation.End)

        # Save the conversation
        save_conversation(f"You: {user_message}\nZero: {response}")

    def set_reminder_interactive(self):
        """
        Guides the user through setting a reminder interactively.
        """
        self.chat_display.append("Zero: Sure! What time should I set the reminder? (Please use HH:MM format)\n")
        self.user_input.setPlaceholderText("Enter time (HH:MM)...")
        self.user_input.returnPressed.disconnect()
        self.user_input.returnPressed.connect(self.set_reminder_time)

    def set_reminder_time(self):
        """
        Sets the reminder time based on user input.
        """
        time_input = self.user_input.text()
        try:
            reminder_time = datetime.strptime(time_input, "%H:%M").time()
            self.chat_display.append(f"Zero: Got it! What should I remind you about?\n")
            self.user_input.setPlaceholderText("Enter reminder message...")
            self.user_input.returnPressed.disconnect()
            self.user_input.returnPressed.connect(lambda: self.set_reminder_message(time_input, reminder_time))
        except ValueError:
            self.chat_display.append("Zero: Invalid time format. Please use HH:MM.\n")
            self.reset_input()

    def set_reminder_message(self, time_input, reminder_time):
        """
        Sets the reminder message based on user input.
        """
        reminder_message = self.user_input.text()
        self.reminders.append(Reminder(reminder_time, reminder_message))
        self.chat_display.append(f"Zero: Reminder set for {time_input} - {reminder_message}\n")
        self.reset_input()

    def reset_input(self):
        """
        Resets the input field to its default state.
        """
        self.user_input.setPlaceholderText("Type your message here...")
        self.user_input.returnPressed.disconnect()
        self.user_input.returnPressed.connect(self.send_message)

    def check_reminders(self):
        """
        Checks and triggers reminders at the specified time.
        """
        now = datetime.now().time()
        for reminder in self.reminders:
            if now.hour == reminder.time.hour and now.minute == reminder.time.minute:
                self.chat_display.append(f"Zero: Reminder! ⏰ - {reminder.message}\n")
                self.reminders.remove(reminder)

    def handle_system_request(self, message):
        """
        Handles system-related requests from the user.
        """
        if "open" in message.lower():
            self.open_file_or_app(message)
        elif "delete" in message.lower():
            self.delete_file(message)
        elif "create" in message.lower():
            self.create_file(message)
        elif "run" in message.lower():
            self.run_command(message)
        elif "change wallpaper" in message.lower():
            self.change_wallpaper(message)
        else:
            self.chat_display.append("Zero: I'm sorry, I couldn't understand your system request.\n")

    def handle_search_request(self, message):
        """
        Handles web search requests from the user.
        """
        query = message.lower().replace("search", "").replace("find", "").replace("look up", "").strip()
        if query:
            results = search_web(query)
            if results:
                self.chat_display.append("Zero: Here are the top search results:\n")
                for i, result in enumerate(results, 1):
                    self.chat_display.append(f"{i}. {result['title']}\n   {result['link']}\n")
            else:
                self.chat_display.append("Zero: Sorry, I couldn't find any results.\n")
        else:
            self.chat_display.append("Zero: Please specify what you want to search for.\n")

    def open_file_or_app(self, message):
        """
        Opens a file or application based on user input.
        """
        try:
            target = message.lower().split("open")[1].strip()
            if os.path.exists(target):
                os.startfile(target) if os.name == "nt" else subprocess.run(["xdg-open", target])
                self.chat_display.append(f"Zero: Opened {target} successfully.\n")
            else:
                self.chat_display.append(f"Zero: Sorry, {target} does not exist.\n")
        except Exception as e:
            self.chat_display.append(f"Zero: Failed to open. Error: {str(e)}\n")

    def delete_file(self, message):
        """
        Deletes a file based on user input.
        """
        try:
            target = message.lower().split("delete")[1].strip()
            if os.path.exists(target):
                os.remove(target)
                self.chat_display.append(f"Zero: Deleted {target} successfully.\n")
            else:
                self.chat_display.append(f"Zero: Sorry, {target} does not exist.\n")
        except Exception as e:
            self.chat_display.append(f"Zero: Failed to delete. Error: {str(e)}\n")

    def create_file(self, message):
        """
        Creates a file based on user input.
        """
        try:
            target = message.lower().split("create")[1].strip()
            with open(target, "w") as file:
                file.write("")
            self.chat_display.append(f"Zero: Created {target} successfully.\n")
        except Exception as e:
            self.chat_display.append(f"Zero: Failed to create. Error: {str(e)}\n")

    def run_command(self, message):
        """
        Runs a system command based on user input.
        """
        try:
            command = message.lower().split("run")[1].strip()
            result = subprocess.run(command, shell=True, capture_output=True, text=True)
            self.chat_display.append(f"Zero: Command executed. Output:\n{result.stdout}\n")
        except Exception as e:
            self.chat_display.append(f"Zero: Failed to run command. Error: {str(e)}\n")

    def change_wallpaper(self, message):
        """
        Changes the desktop wallpaper based on user input.
        """
        try:
            image_path = message.lower().split("change wallpaper")[1].strip()
            if os.path.exists(image_path):
                if os.name == "nt":  # Windows
                    import ctypes
                    ctypes.windll.user32.SystemParametersInfoW(20, 0, image_path, 0)
                elif os.name == "posix":  # Linux or macOS
                    subprocess.run(["gsettings", "set", "org.gnome.desktop.background", "picture-uri", f"file://{image_path}"])
                self.chat_display.append(f"Zero: Wallpaper changed successfully.\n")
            else:
                self.chat_display.append(f"Zero: Sorry, {image_path} does not exist.\n")
        except Exception as e:
            self.chat_display.append(f"Zero: Failed to change wallpaper. Error: {str(e)}\n")

# Run the application
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ChatbotGUI()
    window.show()
    sys.exit(app.exec())