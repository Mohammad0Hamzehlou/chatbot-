from textblob import TextBlob
import ollama

# تابع برای تحلیل احساسات
def analyze_sentiment(text):
    analysis = TextBlob(text)
    if analysis.sentiment.polarity > 0.2:  # احساس مثبت
        return "شاد"
    elif analysis.sentiment.polarity < -0.2:  # احساس منفی
        return "ناراحت"
    else:  # احساس خنثی
        return "خنثی"

# تابع برای تولید پاسخ با Mistral
def generate_response(user_input, sentiment):
    # شخصی‌سازی prompt بر اساس احساسات کاربر
    if sentiment == "شاد":
        prompt = f"کاربر احساس شادی داره. بهش پاسخ بده: {user_input}"
    elif sentiment == "ناراحت":
        prompt = f"کاربر احساس ناراحتی داره. بهش پاسخ بده: {user_input}"
    else:
        prompt = f"کاربر احساس خنثی داره. بهش پاسخ بده: {user_input}"
    
    # تولید پاسخ با Mistral
    response = ollama.generate(model="mistral", prompt=prompt)
    return response['response']

# مکالمه با کاربر
def chat():
    print("چت‌بات: سلام! من می‌تونم احساساتتو از روی متن تشخیص بدم. بیا چت کنیم!")
    while True:
        user_input = input("شما: ")
        if user_input.lower() in ["خداحافظ", "بای", "exit"]:
            print("چت‌بات: خداحافظ! به امید دیدار.")
            break
        
        # تحلیل احساسات کاربر
        sentiment = analyze_sentiment(user_input)
        print(f"چت‌بات: احساس تو رو تشخیص دادم: {sentiment}")
        
        # تولید و نمایش پاسخ
        response = generate_response(user_input, sentiment)
        print(f"چت‌بات: {response}")

# اجرای چت‌بات
if __name__ == "__main__":
    chat()