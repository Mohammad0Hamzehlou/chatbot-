import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QPushButton
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QTextCursor, QColor
from textblob import TextBlob
import ollama
from datetime import datetime

# Function to analyze sentiment
def analyze_sentiment(text):
    analysis = TextBlob(text)
    if analysis.sentiment.polarity > 0.2:  # Positive sentiment
        return "happy", QColor(0, 128, 0)  # Green for happy
    elif analysis.sentiment.polarity < -0.2:  # Negative sentiment
        return "sad", QColor(255, 0, 0)  # Red for sad
    else:  # Neutral sentiment
        return "neutral", QColor(0, 0, 255)  # Blue for neutral

# Function to generate response using Mistral
def generate_response(user_input, sentiment):
    # Customize prompt based on user sentiment
    prompt = f"""
    You are a friendly and helpful chatbot that can understand the user's emotions.
    The user is feeling {sentiment} and said: {user_input}
    Respond to them in a way that matches their emotion:
    """
    
    # Generate response using Mistral
    response = ollama.generate(model="mistral", prompt=prompt)
    return response['response']

# Function to save conversation to a file
def save_conversation(conversation):
    with open("chat_history.txt", "a", encoding="utf-8") as file:
        file.write(f"Conversation on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        file.write(conversation + "\n\n")

# Main GUI class
class ChatbotGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        # Window settings
        self.setWindowTitle("Emotional Chatbot")
        self.setGeometry(100, 100, 600, 400)

        # Create a vertical layout
        layout = QVBoxLayout()

        # Text box to display the conversation
        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)  # Make it read-only
        layout.addWidget(self.chat_display)

        # Input field for the user
        self.user_input = QLineEdit()
        self.user_input.setPlaceholderText("Type your message here...")
        self.user_input.returnPressed.connect(self.send_message)  # Send on Enter
        layout.addWidget(self.user_input)

        # Send button
        send_button = QPushButton("Send")
        send_button.clicked.connect(self.send_message)
        layout.addWidget(send_button)

        # Set the layout
        self.setLayout(layout)

    # Function to send a message
    def send_message(self):
        user_message = self.user_input.text()
        if user_message.strip() == "":
            return  # Do nothing if the message is empty

        # Display the user's message in the text box
        self.chat_display.append(f"You: {user_message}")
        self.user_input.clear()  # Clear the input field

        # Analyze sentiment and generate a response
        sentiment, color = analyze_sentiment(user_message)
        response = generate_response(user_message, sentiment)

        # Display the chatbot's response with color
        self.chat_display.setTextColor(color)
        self.chat_display.append(f"Chatbot: {response}\n")

        # Auto-scroll to the bottom
        self.chat_display.moveCursor(QTextCursor.MoveOperation.End)

        # Save the conversation to a file
        save_conversation(f"You: {user_message}\nChatbot: {response}")

# Run the application
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ChatbotGUI()
    window.show()
    sys.exit(app.exec())