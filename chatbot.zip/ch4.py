import ollama

def chat():
    print("چت‌بات آماده‌ست. برای خروج 'exit' رو تایپ کن.\n")
    while True:
        user_input = input("شما: ")
        if user_input.lower() == "exit":
            print("خروج از چت‌بات...")
            break
        
        response = ollama.chat(model="mistral", messages=[{"role": "user", "content": user_input}])
        print("چت‌بات:", response['message']['content'])

if __name__ == "__main__":
    chat()
