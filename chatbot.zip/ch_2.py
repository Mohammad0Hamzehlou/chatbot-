import sys
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QPushButton, QLabel
)
import nltk
from nltk.chat.util import Chat, reflections

# تعریف جفت‌های سوال و جواب
pairs = [
    [
        r"سلام|درود",
        ["سلام! چطور می‌تونم کمک کنم؟", "درود! چه خبر؟"]
    ],
    [
        r"اسمت چیه؟",
        ["من یک چت‌بات ساده‌ام. تو چی؟"]
    ],
    [
        r"چطوری؟",
        ["خوبم، ممنون! تو چطوری؟"]
    ],
    [
        r"خداحافظ",
        ["خداحافظ! خوش گذشت.", "بای! تا بعد."]
    ],
    [
        r"(.*) سنت چنده؟",
        ["من یک برنامه کامپیوتری‌ام، سنی ندارم! 😊"]
    ],
    [
        r"چه کار می‌کنی؟",
        ["دارم با تو چت می‌کنم! 😄"]
    ],
    [
        r"(.*) کمک (.*)",
        ["چطور می‌تونم کمک کنم؟"]
    ],
    [
        r"متشکرم|ممنون",
        ["خواهش می‌کنم! 😊"]
    ],
]

# ایجاد چت‌بات
chatbot = Chat(pairs, reflections)

# ایجاد کلاس اصلی برنامه
class ChatApp(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        # تنظیمات پنجره
        self.setWindowTitle("چت‌بات PyQt6")
        self.setGeometry(100, 100, 400, 500)

        # ایجاد لایه‌بندی عمودی
        layout = QVBoxLayout()

        # ایجاد ویجت‌ها
        self.chat_area = QTextEdit()
        self.chat_area.setReadOnly(True)
        self.input_box = QLineEdit()
        self.send_button = QPushButton("ارسال")

        # اضافه کردن ویجت‌ها به لایه‌بندی
        layout.addWidget(QLabel("چت‌بات:"))
        layout.addWidget(self.chat_area)
        layout.addWidget(self.input_box)
        layout.addWidget(self.send_button)

        # تنظیم لایه‌بندی
        self.setLayout(layout)

        # اتصال دکمه ارسال به تابع ارسال پیام
        self.send_button.clicked.connect(self.send_message)

    def send_message(self):
        user_input = self.input_box.text()
        self.chat_area.append(f"شما: {user_input}")
        response = chatbot.respond(user_input)
        self.chat_area.append(f"چت‌بات: {response}")
        self.input_box.clear()

        if user_input.lower() == "خداحافظ":
            self.input_box.setDisabled(True)
            self.send_button.setDisabled(True)

# اجرای برنامه
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ChatApp()
    window.show()
    sys.exit(app.exec())